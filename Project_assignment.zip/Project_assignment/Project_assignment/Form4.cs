﻿using Project_assignment.MODEL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_assignment
{
    public partial class Form4 : Form
    {
        DepartmentLogic ob;
        public Form4()
        {
            
            InitializeComponent();
            ob = new DepartmentLogic();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            label1.Visible = true;
            tbdeptid.Visible = true;
            label2.Visible = false;
            tbdeptname.Visible = false;
            label3.Visible = false;
            tbdeptloc.Visible = false;
            label4.Visible = false;
            tbdeptmgrid.Visible = false;
            btncheck.Visible = true;
            btndelete.Visible = false;
            btninsert.Visible = false;
            btnupdate.Visible = false;
            dataGridView1.Visible = false;
        }

        private void btncheck_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(tbdeptid.Text);
            bool es = ob.checkdept(i);
            if (es)
            {
                label1.Visible = true;
                tbdeptid.Visible = true;
                label2.Visible = true;
                tbdeptname.Visible = true;
                label3.Visible = true;
                tbdeptloc.Visible = true;
                label4.Visible = true;
                tbdeptmgrid.Visible = true;
                btninsert.Visible = true;
                btncheck.Visible = false;
                btnupdate.Visible = true;
            }
            else
            {
                MessageBox.Show("data not found please use valid empid");
            }
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            Department esp = new Department();
            esp.DEPTID = Convert.ToInt32(tbdeptid.Text);
            esp.DEPTNAME = tbdeptname.Text.ToString();
            esp.DEPTLOCATION = tbdeptloc.Text.ToString();
            esp.MANAGERID= Convert.ToInt32(tbdeptmgrid.Text);
            string msg = ob.insertdeptsp(esp);
            MessageBox.Show(msg);
            if (msg != null)
            {
                dataGridView1.Visible = true;
                dataGridView1.DataSource = ob.getAllDeptData();
            }
            tbdeptid.Text = "";
            tbdeptname.Text = "";
            tbdeptloc.Text = "";
            tbdeptmgrid.Text = "";
            label1.Visible = true;
            tbdeptid.Visible = true;
            dataGridView1.Visible = true;
            btndelete.Visible = true;
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(tbdeptid.Text);
            bool es = ob.checkdept(i);
            if (es)
            {
                string msg = ob.deletedeptsp(i);
                if (msg != null)
                {
                    dataGridView1.DataSource = ob.getAllDeptData();
                }
                else
                {
                    MessageBox.Show("unable to fetch data....");
                }
            }
            else
            {
                MessageBox.Show("Enter valid EmpID");

            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(tbdeptid.Text);
            bool es = ob.checkdept(i);
            if (es)
            {
                label1.Visible = true;
                tbdeptid.Visible = true;
                label2.Visible = true;
                tbdeptname.Visible = true;
                label3.Visible = true;
                tbdeptloc.Visible = true;
                label4.Visible = true;
                tbdeptmgrid.Visible = true;
                btninsert.Visible = true;
                btncheck.Visible = false;
                Department esp = new Department();
                esp.DEPTID = Convert.ToInt32(tbdeptid.Text);
                esp.DEPTNAME = tbdeptname.Text.ToString();
                esp.DEPTLOCATION = tbdeptloc.Text.ToString();
                esp.MANAGERID = Convert.ToInt32(tbdeptmgrid.Text);
                string msg = ob.updatedeptsp(esp);
                MessageBox.Show(msg);
                if (msg != null)
                {
                    dataGridView1.DataSource = ob.getAllDeptData();
                }
                else
                {
                    MessageBox.Show("unable to update data....");
                }
            }
            else
            {
                MessageBox.Show("Enter valid EmpID");

            }
        }
    }
}
