﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Project_assignment.MODEL
{
    class EmployeeLogic
    {
        private string conStr = ConfigurationManager.ConnectionStrings["empdb"].ConnectionString;

        public List<Employee> getAllData()
        {
            List<Employee> li = new List<Employee>();
            string sql = "select * from Employee";
            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader rdr = cmd.ExecuteReader();
                while(rdr.Read())
                {
                    Employee e = new Employee();
                    e.EID = Convert.ToInt32(rdr.GetValue(0));
                    e.EMPNAME = rdr.GetValue(1).ToString();
                    e.DOB = Convert.ToDateTime(rdr.GetValue(2));
                    e.PHONE = Convert.ToInt64(rdr.GetValue(3));
                    e.EMAIL = rdr.GetValue(4).ToString();
                    e.SALARY = float.Parse(rdr.GetValue(5).ToString());
                    e.DEPTID = Convert.ToInt32(rdr.GetValue(6));
                    li.Add(e);
                }
            }
            catch(Exception)
            {
                MessageBox.Show("Unable to show data");
            }
            finally
            {
                conn.Close();
            }
            return li;
        }
        public Employee search(string str)
        {
            Employee ob1 = new Employee();
            string sql = "select * from Employee where EMPNAME='"+ str+"'";
            SqlConnection conn = new SqlConnection(conStr);

            try
            {
                conn.Open();
                SqlCommand cmdd = new SqlCommand(sql, conn);
                SqlDataReader sqrr = cmdd.ExecuteReader();
                if(sqrr.HasRows)
                {
                    while(sqrr.Read())
                    {
                        ob1.EID = Convert.ToInt32(sqrr.GetValue(0));
                        ob1.EMPNAME = sqrr.GetValue(1).ToString();
                        ob1.DOB = Convert.ToDateTime(sqrr.GetValue(2));
                        ob1.PHONE = Convert.ToInt64(sqrr.GetValue(3));
                        ob1.EMAIL = sqrr.GetValue(4).ToString();
                        ob1.SALARY = float.Parse(sqrr.GetValue(5).ToString());
                        ob1.DEPTID = Convert.ToInt32(sqrr.GetValue(6));

                    }
                }
                else
                {
                    ob1 = null;
                }
            }
            catch(Exception)
            {
                MessageBox.Show("Couldn't find data");
            }
            finally
            {
                conn.Close();
            }
            return ob1;

        }
        public Employee searchsal(float sal)
        {
            Employee ob2 = new Employee();
            string sql = "select * from Employee where SALARY="+sal;
            SqlConnection conn = new SqlConnection(conStr);

            try
            {
                conn.Open();
                SqlCommand cmdd = new SqlCommand(sql, conn);
                SqlDataReader sqrr = cmdd.ExecuteReader();
                if (sqrr.HasRows)
                {
                    while (sqrr.Read())
                    {
                        ob2.EID = Convert.ToInt32(sqrr.GetValue(0));
                        ob2.EMPNAME = sqrr.GetValue(1).ToString();
                        ob2.DOB = Convert.ToDateTime(sqrr.GetValue(2));
                        ob2.PHONE = Convert.ToInt64(sqrr.GetValue(3));
                        ob2.EMAIL = sqrr.GetValue(4).ToString();
                        ob2.SALARY = float.Parse(sqrr.GetValue(5).ToString());
                        ob2.DEPTID = Convert.ToInt32(sqrr.GetValue(6));

                    }
                }
                else
                {
                    ob2 = null;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Couldn't find data");
            }
            finally
            {
                conn.Close();
            }
            return ob2;

        }

        public bool check(int i)
        {
            bool x=false;
            string sql = "select * from Employee where EMPID=" + i;
            SqlConnection conn = new SqlConnection(conStr);
            //Employee ob2 = new Employee();
            try
            {
                conn.Open();
                SqlCommand cmdd = new SqlCommand(sql, conn);
                SqlDataReader sqrr = cmdd.ExecuteReader();
                if (sqrr.HasRows)
                {
                    x = true;
                }
                else
                {
                    x = false;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Couldn't find data");
            }
            finally
            {
                conn.Close();
            }
            return x;
        }
        public string insertsp(Employee esp)
        {
            string msg = "";
            string sql = "spinsertemployee";
            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EMPID", SqlDbType.Int).Value = esp.EID;
                cmd.Parameters.Add("@EMPNAME", SqlDbType.VarChar, 50).Value = esp.EMPNAME;
                cmd.Parameters.Add("@DOB", SqlDbType.Date).Value = esp.DOB;
                cmd.Parameters.Add("@PHONE", SqlDbType.BigInt).Value = esp.PHONE;
                cmd.Parameters.Add("@EMAIL", SqlDbType.VarChar, 50).Value = esp.EMAIL;
                cmd.Parameters.Add("@SALARY", SqlDbType.Float).Value = esp.SALARY;
                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = esp.DEPTID;
                cmd.ExecuteNonQuery();
                msg = "Data Inserted Successfully";
            }
            catch(Exception)
            {
                MessageBox.Show("unable to insert data");
            }
            finally
            {
                conn.Close();
            }

            return msg;
        }
        public string deletesp(int id)
        {
            string msg = "";
            string sql = "spdeleteemployee";
            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EID", id);
                cmd.ExecuteNonQuery();
                msg = "Data Deleted Successfully";
            }
            catch (Exception)
            {
                MessageBox.Show("unable to delete data");
            }
            finally
            {
                conn.Close();
            }

            return msg;
        }
        public string updatesp(Employee esp)
        {
            string msg = "";
            string sql = "spupdateemployee";
            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EMPID", SqlDbType.Int).Value = esp.EID;
                cmd.Parameters.Add("@EMPNAME", SqlDbType.VarChar, 50).Value = esp.EMPNAME;
                cmd.Parameters.Add("@DOB", SqlDbType.Date).Value = esp.DOB;
                cmd.Parameters.Add("@PHONE", SqlDbType.BigInt).Value = esp.PHONE;
                cmd.Parameters.Add("@EMAIL", SqlDbType.VarChar, 50).Value = esp.EMAIL;
                cmd.Parameters.Add("@SALARY", SqlDbType.Float).Value = esp.SALARY;
                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = esp.DEPTID;
                cmd.ExecuteNonQuery();
                msg = "Data Updated Successfully";
            }
            catch (Exception)
            {
                MessageBox.Show("unable to updated data");
            }
            finally
            {
                conn.Close();
            }

            return msg;
        }

        public DataTable getjointable()
        {
            DataTable dt = new DataTable("tablejoin");
            SqlConnection conn = new SqlConnection(conStr);
            string sql = "select E.EMPNAME,E.DOB,E.PHONE,E.EMAIL, D.DEPTNAME,D.DEPTLOCATION FROM EMPLOYEE E INNER JOIN DEPARTMENT D ON E.EMPID=D.MANAGERID";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch(Exception)
            {
                MessageBox.Show("Unable to fetch data");
            }
            finally
            {
                conn.Close();
            }
            return dt;
        }

    }
}
