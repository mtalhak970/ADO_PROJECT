﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Project_assignment.MODEL
{
    class DepartmentLogic
    {
        private string conStr = ConfigurationManager.ConnectionStrings["empdb"].ConnectionString;

        public List<Department> getAllDeptData()
        {
            List<Department> li = new List<Department>();
            string sql = "select * from Department";
            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Department e = new Department();
                    e.DEPTID = Convert.ToInt32(rdr.GetValue(0));
                    e.DEPTNAME = rdr.GetValue(1).ToString();
                    e.DEPTLOCATION = rdr.GetValue(2).ToString();
                    e.MANAGERID = Convert.ToInt32(rdr.GetValue(3));
                    li.Add(e);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to show data");
            }
            finally
            {
                conn.Close();
            }
            return li;
        }
        public bool checkdept(int i)
        {
            bool x = false;
            string sql = "select * from Department where DEPTID=" + i;
            SqlConnection conn = new SqlConnection(conStr);
            
            try
            {
                conn.Open();
                SqlCommand cmdd = new SqlCommand(sql, conn);
                SqlDataReader sqrr = cmdd.ExecuteReader();
                if (sqrr.HasRows)
                {
                    x = true;
                }
                else
                {
                    x = false;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Couldn't find data");
            }
            finally
            {
                conn.Close();
            }
            return x;
        }
        public string insertdeptsp(Department esp)
        {
            string msg = "";
            string sql = "spinsertdepartment";
            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = esp.DEPTID;
                cmd.Parameters.Add("@DEPTNAME", SqlDbType.VarChar, 50).Value = esp.DEPTNAME;
                cmd.Parameters.Add("@DEPTLOCATION", SqlDbType.VarChar, 50).Value = esp.DEPTLOCATION;
                cmd.Parameters.Add("@MANAGERID", SqlDbType.Int).Value = esp.MANAGERID;
                cmd.ExecuteNonQuery();
                msg = "Data Inserted Successfully";
            }
            catch (Exception)
            {
                MessageBox.Show("unable to insert data");
            }
            finally
            {
                conn.Close();
            }

            return msg;
        }
        public string deletedeptsp(int id)
        {
            string msg = "";
            string sql = "spdeletedepartment";
            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@DEPTID", id);
                cmd.ExecuteNonQuery();
                msg = "Data Deleted Successfully";
            }
            catch (Exception)
            {
                MessageBox.Show("unable to delete data");
            }
            finally
            {
                conn.Close();
            }

            return msg;
        }
        public string updatedeptsp(Department esp)
        {
            string msg = "";
            string sql = "spupdatedepartment";
            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = esp.DEPTID;
                cmd.Parameters.Add("@DEPTNAME", SqlDbType.VarChar, 50).Value = esp.DEPTNAME;
                cmd.Parameters.Add("@DEPTLOC", SqlDbType.VarChar, 50).Value = esp.DEPTLOCATION;
                cmd.Parameters.Add("@MGRID", SqlDbType.Int).Value = esp.MANAGERID;
                cmd.ExecuteNonQuery();
                msg = "Data Updated Successfully";
            }
            catch (Exception)
            {
                MessageBox.Show("unable to updated data");
            }
            finally
            {
                conn.Close();
            }

            return msg;
        }

    }
}
