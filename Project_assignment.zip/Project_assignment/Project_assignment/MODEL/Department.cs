﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_assignment.MODEL
{
    class Department
    {
        public int DEPTID { get; set; }
        public string DEPTNAME { get; set; }
        public string DEPTLOCATION { get; set; }
        public int MANAGERID { get; set; }
    }
}
