﻿using Project_assignment.MODEL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_assignment
{
    public partial class Form1 : Form
    {
        EmployeeLogic ob;
        public Form1()
        {
            InitializeComponent();
            ob = new EmployeeLogic();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            string str;
            str = tbeid.Text.ToString();
            Employee es = ob.search(str);
            if(es==null)
            {
                MessageBox.Show("Search name not found");
            }
            else
            {
                dataGridView1.Visible = true;
                List<Employee> li = new List<Employee>();
                li.Add(es);
                dataGridView1.DataSource = li;
                MessageBox.Show("data found");
            }
        }

        private void btnsearchsal_Click(object sender, EventArgs e)
        {
            float sal;
            sal = float.Parse(tbsal.Text.ToString());
            Employee es1 = ob.searchsal(sal);
            if (es1 == null)
            {
                MessageBox.Show("Search salary not found");
            }
            else
            {
                dataGridView1.Visible = true;
                List<Employee> li = new List<Employee>();
                li.Add(es1);
                dataGridView1.DataSource = li;
                MessageBox.Show("data found");
            }
        }
    }
}
