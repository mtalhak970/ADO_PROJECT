﻿using Project_assignment.MODEL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_assignment
{
    public partial class Form2 : Form
    {
        EmployeeLogic ob;
        public Form2()
        {
            InitializeComponent();
            ob = new EmployeeLogic();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label1.Visible = true;
            tbeid.Visible = true;
            label2.Visible = false;
            tbempname.Visible = false;
            label3.Visible = false;
            tbdob.Visible = false;
            label4.Visible = false;
            tbphone.Visible = false;
            label5.Visible = false;
            tbemail.Visible = false;
            label6.Visible = false;
            tbsal.Visible = false;
            label7.Visible = false;
            tbdeptid.Visible = false;
            btninsert.Visible = false;
            btncheck.Visible = true;
            dataGridView1.Visible = false;
            btndelete.Visible = false;
            btnupdate.Visible = false;
        }

        private void btncheck_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(tbeid.Text);
            bool es = ob.check(i);
            if (es)
            {
                label1.Visible = true;
                tbeid.Visible = true;
                label2.Visible = true;
                tbempname.Visible = true;
                label3.Visible = true;
                tbdob.Visible = true;
                label4.Visible = true;
                tbphone.Visible = true;
                label5.Visible = true;
                tbemail.Visible = true;
                label6.Visible = true;
                tbsal.Visible = true;
                label7.Visible = true;
                tbdeptid.Visible = true;
                btninsert.Visible = true;
                btncheck.Visible = false;
                btnupdate.Visible = true;

            }
            else
            {
                MessageBox.Show("data not found please use valid empid");
            }
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            Employee esp = new Employee();
            esp.EID = Convert.ToInt32(tbeid.Text);
            esp.EMPNAME = tbempname.Text.ToString();
            esp.DOB = Convert.ToDateTime(tbdob.Text);
            esp.PHONE = Convert.ToInt64(tbphone.Text);
            esp.EMAIL = tbemail.Text.ToString();
            esp.SALARY = float.Parse(tbsal.Text.ToString());
            esp.DEPTID = Convert.ToInt32(tbdeptid.Text);
            string msg = ob.insertsp(esp);
            MessageBox.Show(msg);
            if(msg!=null)
            {
                dataGridView1.Visible = true;
                dataGridView1.DataSource = ob.getAllData();
            }
            tbeid.Text = "";
            tbempname.Text = "";
            tbdob.Text = "";
            tbphone.Text = "";
            tbemail.Text = "";
            tbsal.Text = "";
            tbdeptid.Text = "";
            label1.Visible = true;
            tbeid.Visible = true;
            dataGridView1.Visible = true;
            btndelete.Visible = true;
            

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            
            int i;
            i = Convert.ToInt32(tbeid.Text);
            bool es = ob.check(i);
            if (es)
            {
                string msg = ob.deletesp(i);
                if(msg!=null)
                {
                    dataGridView1.DataSource = ob.getAllData();
                }
                else
                {
                    MessageBox.Show("unable to fetch data....");
                }
            }
            else
            {
                MessageBox.Show("Enter valid EmpID");

            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(tbeid.Text);
            bool es = ob.check(i);
            if (es)
            {
                label1.Visible = true;
                tbeid.Visible = true;
                label2.Visible = true;
                tbempname.Visible = true;
                label3.Visible = true;
                tbdob.Visible = true;
                label4.Visible = true;
                tbphone.Visible = true;
                label5.Visible = true;
                tbemail.Visible = true;
                label6.Visible = true;
                tbsal.Visible = true;
                label7.Visible = true;
                tbdeptid.Visible = true;
                btninsert.Visible = true;
                btncheck.Visible = false;
                btndelete.Visible = true;
                Employee esp = new Employee();
                esp.EID = Convert.ToInt32(tbeid.Text);
                esp.EMPNAME = tbempname.Text.ToString();
                esp.DOB = Convert.ToDateTime(tbdob.Text);
                esp.PHONE = Convert.ToInt64(tbphone.Text);
                esp.EMAIL = tbemail.Text.ToString();
                esp.SALARY = float.Parse(tbsal.Text.ToString());
                esp.DEPTID = Convert.ToInt32(tbdeptid.Text);
                string msg = ob.updatesp(esp);
                if (msg != null)
                {
                    dataGridView1.Visible = true;
                    dataGridView1.DataSource = ob.getAllData();
                    tbeid.Text = "";
                    tbempname.Text = "";
                    tbdob.Text = "";
                    tbphone.Text = "";
                    tbemail.Text = "";
                    tbsal.Text = "";
                    tbdeptid.Text = "";
                }
                else
                {
                    MessageBox.Show("unable to fetch data....");
                }
            }
            else
            {
                MessageBox.Show("Enter valid EmpID");

            }
        }
    }
}
